package controllers;

import entities.Department;
import entities.Employee;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import services.DepartmentService;
import services.DepartmentServiceImpl;
import services.EmployeeService;
import services.EmployeeServiceImpl;
import utils.AlertUtils;

import java.net.URL;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    private final DepartmentService departmentService = new DepartmentServiceImpl();
    private final EmployeeService employeeService = new EmployeeServiceImpl();

    @FXML private AnchorPane homePane;
    @FXML private AnchorPane employeesPane;
    @FXML private AnchorPane departmentsPane;

    @FXML private TextField name;
    @FXML private TextField email;
    @FXML private TextField phone;
    @FXML private TextField role;
    @FXML private ComboBox<Department> departmentComboBox;
    @FXML private TableColumn<Employee, Integer> employeeID;
    @FXML private TableColumn<Employee, String> employeeName;
    @FXML private TableColumn<Employee, String> employeeEmail;
    @FXML private TableColumn<Employee, String> employeePhone;
    @FXML private TableColumn<Employee, String> employeeRole;
    @FXML private TableColumn<Employee, String> employeeDepartement;

    @FXML private TableColumn<Department, Integer> departmentID;
    @FXML private TableColumn<Department, String> departmentName;
    @FXML private TableColumn<Department, String> departmentDescription;
    @FXML private TableColumn<Department, String> departmentPhone;
    @FXML private TableColumn<Department, String> departmentEmail;
    @FXML private TextField nameTF;
    @FXML private TextField descriptionTF;
    @FXML private TextField phoneTF;
    @FXML private TextField emailTF;
    @FXML
    private Button department_add_btn1;
    @FXML
    private TextField addDepartment_search;
    @FXML
    private TableView table_view;
    @FXML
    private TableView departmentTable;
    @FXML
    private Button department_delete_btn;
    @FXML
    private TableView employeeTable;
    @FXML
    private Button department_add_btn;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initPanes();
        initDepartmentTable();
        initEmployeeTable();
    }

    private void initPanes() {
        homePane.setVisible(true);
        employeesPane.setVisible(false);
        departmentsPane.setVisible(false);
    }

    private void initDepartmentTable() {
        departmentID.setCellValueFactory(new PropertyValueFactory<>("id"));
        departmentName.setCellValueFactory(new PropertyValueFactory<>("name"));
        departmentDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        departmentPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        departmentEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

        departmentTable.getItems().addAll(departmentService.getAllDepartments());
    }

    private void initEmployeeTable() {
        employeeID.setCellValueFactory(new PropertyValueFactory<>("id"));
        employeeName.setCellValueFactory(new PropertyValueFactory<>("name"));
        employeeEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        employeePhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        employeeRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        employeeDepartement.setCellValueFactory(new PropertyValueFactory<>("department"));

        employeeTable.getItems().addAll(employeeService.getAllEmployees());
        departmentComboBox.getItems().addAll(departmentService.getAllDepartments());
    }

    @FXML
    public void showHome() {
        homePane.setVisible(true);
        employeesPane.setVisible(false);
        departmentsPane.setVisible(false);
    }

    @FXML
    public void showDepartments() {
        homePane.setVisible(false);
        employeesPane.setVisible(false);
        departmentsPane.setVisible(true);
    }

    @FXML
    public void showEmployees() {
        homePane.setVisible(false);
        employeesPane.setVisible(true);
        departmentsPane.setVisible(false);
    }

    @FXML
    public void handleAddEmployee() {
        try {
            Employee employee = new Employee(
                    0,
                    name.getText(),
                    email.getText(),
                    phone.getText(),
                    role.getText(),
                    departmentComboBox.getValue().getName()
            );
            employeeService.addEmployee(employee);
            employeeTable.getItems().add(employee);
            clearEmployeeFields();
            AlertUtils.showInfo("Employee added successfully!");
        } catch (Exception e) {
            AlertUtils.showError("Error adding employee: " + e.getMessage());
        }
    }

    @FXML
    public void handleUpdateEmployee() {
        Employee selected = employeeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                selected.setName(name.getText());
                selected.setEmail(email.getText());
                selected.setPhone(phone.getText());
                selected.setRole(role.getText());
                selected.setDepartment(departmentComboBox.getValue().getName());
                employeeService.updateEmployee(selected);
                employeeTable.refresh();
                AlertUtils.showInfo("Employee updated successfully!");
            } catch (Exception e) {
                AlertUtils.showError("Error updating employee: " + e.getMessage());
            }
        }
    }

    @FXML
    public void handleDeleteEmployee() {
        Employee selected = employeeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                employeeService.deleteEmployee(selected.getId());
                employeeTable.getItems().remove(selected);
                AlertUtils.showInfo("Employee deleted successfully!");
            } catch (Exception e) {
                AlertUtils.showError("Error deleting employee: " + e.getMessage());
            }
        }
    }

    @FXML
    public void handleEmployeeTableClick() {
        Employee selected = employeeTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            name.setText(selected.getName());
            email.setText(selected.getEmail());
            phone.setText(selected.getPhone());
            role.setText(selected.getRole());

            departmentComboBox.getItems().stream()
                    .filter(d -> d.getName().equals(selected.getDepartment()))
                    .findFirst()
                    .ifPresent(departmentComboBox::setValue);
        }
    }

    private void clearEmployeeFields() {
        name.clear();
        email.clear();
        phone.clear();
        role.clear();
        departmentComboBox.getSelectionModel().clearSelection();
    }

    @FXML
    public void handleAddDepartment() {
        try {
            Department department = new Department(
                    0,
                    nameTF.getText(),
                    descriptionTF.getText(),
                    phoneTF.getText(),
                    emailTF.getText()
            );
            departmentService.addDepartment(department);
            departmentTable.getItems().add(department);
            departmentComboBox.getItems().add(department);
            clearDepartmentFields();
            AlertUtils.showInfo("Department added successfully!");
        } catch (Exception e) {
            AlertUtils.showError("Error adding department: " + e.getMessage());
        }
    }

    @FXML
    public void handleUpdateDepartment() {
        Department selected = departmentTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                selected.setName(nameTF.getText());
                selected.setDescription(descriptionTF.getText());
                selected.setPhone(phoneTF.getText());
                selected.setEmail(emailTF.getText());
                departmentService.updateDepartment(selected);
                departmentTable.refresh();
                departmentComboBox.getItems().setAll(departmentService.getAllDepartments());
                AlertUtils.showInfo("Department updated successfully!");
            } catch (Exception e) {
                AlertUtils.showError("Error updating department: " + e.getMessage());
            }
        }
    }

    @FXML
    public void handleDeleteDepartment() {
        Department selected = departmentTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try {
                departmentService.deleteDepartment(selected.getId());
                departmentTable.getItems().remove(selected);
                departmentComboBox.getItems().remove(selected);
                AlertUtils.showInfo("Department deleted successfully!");
            } catch (Exception e) {
                AlertUtils.showError("Error deleting department: " + e.getMessage());
            }
        }
    }

    @FXML
    public void handleDepartmentTableClick() {
        Department selected = departmentTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            nameTF.setText(selected.getName());
            descriptionTF.setText(selected.getDescription());
            phoneTF.setText(selected.getPhone());
            emailTF.setText(selected.getEmail());
        }
    }

    private void clearDepartmentFields() {
        nameTF.clear();
        descriptionTF.clear();
        phoneTF.clear();
        emailTF.clear();
    }

    @FXML
    public void handleTableClick(Event event) {
    }
}