package services;

import entities.Department;
import java.util.List;

public interface DepartmentService {
    void addDepartment(Department department);
    void updateDepartment(Department department);
    void deleteDepartment(int id);
    List<Department> getAllDepartments();
    Department getDepartmentById(int id);
}