package services;

import entities.Department;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DepartmentServiceImpl implements DepartmentService {
    private static List<Department> departments = new ArrayList<>();
    private static int nextId = 1;

    @Override
    public void addDepartment(Department department) {
        department.setId(nextId++);
        departments.add(department);
    }

    @Override
    public void updateDepartment(Department department) {
        departments = departments.stream()
                .map(d -> d.getId() == department.getId() ? department : d)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteDepartment(int id) {
        departments.removeIf(d -> d.getId() == id);
    }

    @Override
    public List<Department> getAllDepartments() {
        return new ArrayList<>(departments);
    }

    @Override
    public Department getDepartmentById(int id) {
        return departments.stream()
                .filter(d -> d.getId() == id)
                .findFirst()
                .orElse(null);
    }
}