package services;

import entities.Employee;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeServiceImpl implements EmployeeService {
    private static List<Employee> employees = new ArrayList<>();
    private static int nextId = 1;

    @Override
    public void addEmployee(Employee employee) {
        employee.setId(nextId++);
        employees.add(employee);
    }

    @Override
    public void updateEmployee(Employee employee) {
        employees = employees.stream()
                .map(e -> e.getId() == employee.getId() ? employee : e)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteEmployee(int id) {
        employees.removeIf(e -> e.getId() == id);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return new ArrayList<>(employees);
    }

    @Override
    public Employee getEmployeeById(int id) {
        return employees.stream()
                .filter(e -> e.getId() == id)
                .findFirst()
                .orElse(null);
    }
}